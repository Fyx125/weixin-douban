const network = {
  //获取电影
  getMovieList: function (params) {
    params.type = 'movie';
    this.getItemList(params);
  },
  //获取电视
  getTVList: function (params) {
    params.type='tv';
    this.getItemList(params);
  },
  //获取item列表
  getItemList: function (params) {
    var url='';
    if(params.type==='movie'){
      url ='http://v.juhe.cn/movie/index?key=e3e16f134890be77a18e644c016e081f&title=哥斯拉&smode=0';
    }else{
      url ='http://v.juhe.cn/movie/index?key=e3e16f134890be77a18e644c016e081f&title=奥特曼&smode=0';
    }
    // var pagesize = params.pagesize ? params.pagesize : 7;
    wx.request({
      // url:url,
      // data: {
      //   pagesize: pagesize
      // },
      success: function (res) {
        var items = res.data.result;
        var itemsCount=items.length;
        var left=itemsCount%3;
        if(left===2){
          items.push(null);
        }
        if (params && params.success) {
          params.success(items);
        }
        //console.log(items);
      }
    })
  },
  //获取详细
  getItemDetail:function(params){
    var type=params.type;
    var movieid = params.movieid;
    var url='';
    if (params.type === 'movie') {
      url = 'http://v.juhe.cn/movie/query?key=e3e16f134890be77a18e644c016e081f';
    } else {
      url = 'http://v.juhe.cn/movie/query?key=e3e16f134890be77a18e644c016e081f';
    }
    wx:wx.request({
      // url: url,
      data:{
        movieid: movieid
      },
      success: function(res) {
        //console.log(res);
        var item=res.data.result;
        if (params && params.success) {
          params.success(item);
        }
      }
    })
  },
  //搜索item
  getSearch:function(params){
    var title = params.title;
    var url = 'http://v.juhe.cn/movie/index?key=e3e16f134890be77a18e644c016e081f&smode=0';
    wx.request({
      // url: url,
      data:{
        title:title
      },
      success:function(res){
        //console.log(res);
        var items=res.data.result;
        if (params && params.success) {
          params.success(items);
        }
      }
    })
  }
}

export { network }