//index.js
//获取应用实例
const app = getApp()

import {network} from "../../utils/network.js"

Page({
  data: {

  },
  /**
   * 生命周期函数
   */
  onLoad: function (options) {
    var that=this;
    // 电影
    network.getMovieList({
      success:function(movies){
        that.setData({
          movies: movies
        })
      }
    });
    // 电视剧
    network.getTVList({
      success: function (tvs) {
        that.setData({
          tvs: tvs
        })
      }
    });

    // wx.request({
    //   url: 'http://v.juhe.cn/movie/index?key=e3e16f134890be77a18e644c016e081f&title=哥斯拉',
    //   success:function(res){
    //     var movies=res.data.result;
    //     that.setData({
    //       movies:movies
    //     })
    //   }
    // })
  },
})
