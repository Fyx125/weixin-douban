// pages/search/search.js
import {network} from "../../utils/network.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.getStorage({
      key: 'searched',
      success: function(res) {
        //console.log(res);
        var data=res.data;
        console.log(data);
        that.setData({
          histories:data
        });
      },
    });
  },
  /**
   * 搜索
   */
  onSearchInputEvent:function(event){
    var that=this;
    var value=event.detail.value;
    // if(!value||value===''){
    //   that.setData({
    //     items:null
    //   });
    //   return;
    // }
    network.getSearch({
      title:value,
      success:function(items){
        console.log(items);
        var rate = items.rating;
        var rateText = rate && rate > 0 ? rate.toFixed(1) : "未评";
        that.setData({
          items:items,
          rateText:rateText
        });
      }
    });
  },
  /**
   * 搜索栏item页面跳转
   */
  onItemTapEvent:function(event){
    //console.log(event);
    var that=this;
    var movieid = event.currentTarget.dataset.movieid;
    var title = event.currentTarget.dataset.title;
    var histories=that.data.histories;
    var isExisted=false;
    if(histories){
      for (var index = 0; index <= histories.length; index++) {
        var movie = histories[index];
        if (movie.movieid === movieid) {
          isExisted = true;
          break;
        }
      }
    }
    if (!isExisted){
      if(!histories){
        histories=[];
      }
      histories.push({ movieid: movieid, title: title });
      wx.setStorage({
        key: 'searched',
        data: histories,
        success: function () {
          console.log("保存成功!");
        }
      });
    }
    wx.navigateTo({
      url: "/pages/detail/detail?type=movie&movieid="+movieid
    })
  },
  /**
   * 清除搜索记录
   */
  onClearEvent:function(event){
    wx:wx.removeStorage({
      key: 'searched',
      success: function(res) {
        console.log("删除成功！");
      },
      fail: function(res) {},
      complete: function(res) {},
    });
    this.setData({
      histories:null
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})